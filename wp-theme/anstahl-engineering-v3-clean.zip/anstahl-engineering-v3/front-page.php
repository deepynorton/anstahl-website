<?php
/**
 * Front page template.
 *
 * @package Anstahl_Engineering
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<!-- Hero -->
<section class="hero" id="hero" aria-labelledby="hero-title">
	<div class="hero__media">
		<img
			src="<?php echo esc_url( anstahl_get_image_url( 'hero-turbine.svg' ) ); ?>"
			alt=""
			loading="eager"
			decoding="async"
			fetchpriority="high"
			width="1920"
			height="1080"
		>
	</div>
	<div class="hero__overlay" aria-hidden="true"></div>
	<div class="container hero__content">
		<p class="overline"><?php esc_html_e( 'PT Anstahl Engineering Asia', 'anstahl-engineering' ); ?></p>
		<h1 id="hero-title" class="hero__title">
			<?php esc_html_e( 'Engineering Tomorrow Through Industrial Innovation', 'anstahl-engineering' ); ?>
		</h1>
		<p class="hero__subtitle">
			<?php esc_html_e( 'Industrial innovation, manufacturing excellence, and multidisciplinary engineering consultancy for a more efficient and sustainable future.', 'anstahl-engineering' ); ?>
		</p>
		<div class="hero__actions">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'competence' ),
				'label' => __( 'Explore Our Solutions', 'anstahl-engineering' ),
				'style' => 'primary',
				'size'  => 'lg',
			) );
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'contact' ),
				'label' => __( 'Speak with an Engineer', 'anstahl-engineering' ),
				'style' => 'secondary',
				'size'  => 'lg',
			) );
			?>
		</div>
	</div>
</section>

<!-- Products Overview -->
<section class="section section--surface" id="products" aria-labelledby="products-title">
	<div class="container">
		<?php
		anstahl_section_header( array(
			'overline'    => __( 'Our Brands', 'anstahl-engineering' ),
			'title'       => __( 'Products Overview', 'anstahl-engineering' ),
			'description' => __( 'Three engineered product lines. One commitment to performance.', 'anstahl-engineering' ),
			'align'       => 'center',
		) );
		?>
		<div class="grid grid--3">
			<?php foreach ( anstahl_get_products() as $product ) : ?>
				<?php get_template_part( 'template-parts/components/card', 'product', $product ); ?>
			<?php endforeach; ?>
		</div>
		<div class="section__cta">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'products' ),
				'label' => __( 'View All Products', 'anstahl-engineering' ),
				'style' => 'ghost',
				'icon'  => true,
			) );
			?>
		</div>
	</div>
</section>

<!-- Competence Overview -->
<section class="section section--bg" id="competencies" aria-labelledby="competencies-title">
	<div class="container">
		<?php
		anstahl_section_header( array(
			'overline'    => __( 'What We Do', 'anstahl-engineering' ),
			'title'       => __( 'Competence Overview', 'anstahl-engineering' ),
			'description' => __( 'Our multidisciplinary capabilities span the full engineering lifecycle—from concept and design through manufacturing, commissioning, and continuous improvement.', 'anstahl-engineering' ),
			'align'       => 'center',
		) );
		?>
		<div class="grid grid--3">
			<?php foreach ( anstahl_get_competencies() as $competence ) : ?>
				<?php get_template_part( 'template-parts/components/card', 'competence', $competence ); ?>
			<?php endforeach; ?>
		</div>
		<div class="section__cta">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'competence' ),
				'label' => __( 'View All Competencies', 'anstahl-engineering' ),
				'style' => 'ghost',
				'icon'  => true,
			) );
			?>
		</div>
	</div>
</section>

<!-- Projects Overview -->
<section class="section section--surface" id="projects" aria-labelledby="projects-title">
	<div class="container">
		<?php
		anstahl_section_header( array(
			'overline'    => __( 'Our Work', 'anstahl-engineering' ),
			'title'       => __( 'Projects Overview', 'anstahl-engineering' ),
			'description' => __( 'Real engineering. Measurable outcomes.', 'anstahl-engineering' ),
			'align'       => 'left',
		) );
		?>
		<div class="grid grid--2">
			<?php foreach ( anstahl_get_projects() as $project ) : ?>
				<?php get_template_part( 'template-parts/components/card', 'project', $project ); ?>
			<?php endforeach; ?>
		</div>
		<div class="section__cta section__cta--left">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'projects' ),
				'label' => __( 'View All Projects', 'anstahl-engineering' ),
				'style' => 'ghost',
				'icon'  => true,
			) );
			?>
		</div>
	</div>
</section>

<!-- Innovation Overview -->
<section class="section section--bg" id="innovation" aria-labelledby="innovation-title">
	<div class="container">
		<?php
		anstahl_section_header( array(
			'overline'    => __( 'R&D & Innovation', 'anstahl-engineering' ),
			'title'       => __( 'Innovation Overview', 'anstahl-engineering' ),
			'description' => __( 'Engineering innovation is embedded in how we work—not reserved for R&D laboratories.', 'anstahl-engineering' ),
			'align'       => 'center',
		) );
		?>
		<div class="grid grid--2">
			<?php foreach ( anstahl_get_innovations() as $innovation ) : ?>
				<?php get_template_part( 'template-parts/components/card', 'innovation', $innovation ); ?>
			<?php endforeach; ?>
		</div>
		<div class="section__cta">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'innovation' ),
				'label' => __( 'Explore Innovation', 'anstahl-engineering' ),
				'style' => 'ghost',
				'icon'  => true,
			) );
			?>
		</div>
	</div>
</section>

<!-- Approach Overview -->
<section class="section section--surface" id="approach" aria-labelledby="approach-title">
	<div class="container">
		<?php
		anstahl_section_header( array(
			'overline'    => __( 'How We Work', 'anstahl-engineering' ),
			'title'       => __( 'Approach Overview', 'anstahl-engineering' ),
			'description' => __( 'Safety, quality, ethics, sustainability, and community—embedded in every engineering decision we make.', 'anstahl-engineering' ),
			'align'       => 'center',
		) );
		?>
		<div class="grid grid--5">
			<?php foreach ( anstahl_get_values() as $value ) : ?>
				<?php get_template_part( 'template-parts/components/card', 'values', $value ); ?>
			<?php endforeach; ?>
		</div>
		<div class="section__cta">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'approach' ),
				'label' => __( 'Learn About Our Approach', 'anstahl-engineering' ),
				'style' => 'ghost',
				'icon'  => true,
			) );
			?>
		</div>
	</div>
</section>

<!-- Contact CTA -->
<section class="section section--cta" id="contact-cta" aria-labelledby="contact-cta-title">
	<div class="container section--cta__inner">
		<h2 id="contact-cta-title" class="section--cta__title">
			<?php esc_html_e( "Let's Build the Future Together", 'anstahl-engineering' ); ?>
		</h2>
		<p class="section--cta__desc">
			<?php esc_html_e( 'Whether you need engineered products, manufacturing capability, automation integration, or multidisciplinary consultancy—PT Anstahl Engineering Asia is ready to partner with you.', 'anstahl-engineering' ); ?>
		</p>
		<div class="section--cta__actions">
			<?php
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'contact' ),
				'label' => __( 'Request a Consultation', 'anstahl-engineering' ),
				'style' => 'white',
				'size'  => 'lg',
			) );
			anstahl_button( array(
				'url'   => anstahl_get_page_url( 'contact' ),
				'label' => __( 'Speak with an Engineer', 'anstahl-engineering' ),
				'style' => 'outline-white',
				'size'  => 'lg',
			) );
			?>
		</div>
	</div>
</section>

<?php
get_footer();
